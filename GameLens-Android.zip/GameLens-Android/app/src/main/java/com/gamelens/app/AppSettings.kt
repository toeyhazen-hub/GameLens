package com.gamelens.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** การตั้งค่าทั้งหมด (บันทึกอัตโนมัติ และ UI อัปเดตตามทันที) */
class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("gamelens", Context.MODE_PRIVATE)

    /** เรียกทุกครั้งที่ค่าเปลี่ยน */
    var onChange: (() -> Unit)? = null

    var sourceLangId by stringPref("sourceLang", "en")
    var targetLangId by stringPref("targetLang", "th")
    private var engineName by stringPref("engine", TranslationEngine.MLKIT.name)
    var claudeModel by stringPref("claudeModel", "claude-haiku-4-5-20251001")
    var claudeApiKey by stringPref("claudeKey", "")
    var myMemoryEmail by stringPref("myMemoryEmail", "")
    var fallbackToGoogle by boolPref("fallbackToGoogle", true)

    var fontSize by floatPref("fontSize", 24f)
    var opacity by floatPref("opacity", 0.85f)
    var colorIndex by intPref("colorIndex", 0)
    var showOriginal by boolPref("showOriginal", true)
    var showPronunciation by boolPref("showPronunciation", false)
    private var overlayName by stringPref("overlay", OverlayPosition.AUTO.name)

    var ocrInterval by floatPref("ocrInterval", 0.4f)
    var stableFrames by intPref("stableFrames", 2)
    var hideWhenNoText by boolPref("hideWhenNoText", true)

    var audioEnabled by boolPref("audioEnabled", true)
    var audioVolume by floatPref("audioVolume", 1f)

    var subtitleScreenMode by boolPref("subtitleScreen", false)
    var subtitleLines by intPref("subtitleLines", 2)
    /** แสดงกรอบเส้นประรอบบริเวณที่ OCR (ปิดได้หลังตีกรอบเสร็จ) */
    var showRegionOutline by boolPref("showRegionOutline", true)
    /** ความละเอียดสูงสุดที่ขอจาก Capture Card (1080 / 1440 / 2160) */
    var maxResolution by intPref("maxResolution", 1080)
    /** แสดง FPS และข้อมูลตรวจสอบบนจอ */
    var showDiagnostics by boolPref("showDiagnostics", false)
    private var roiText by stringPref("roi", "")

    var engine: TranslationEngine
        get() = TranslationEngine.entries.firstOrNull { it.name == engineName } ?: TranslationEngine.MLKIT
        set(value) { engineName = value.name }

    var overlayPosition: OverlayPosition
        get() = OverlayPosition.entries.firstOrNull { it.name == overlayName } ?: OverlayPosition.AUTO
        set(value) { overlayName = value.name }

    var roi: NormRect?
        get() = NormRect.decode(roiText)
        set(value) { roiText = value?.encode() ?: "" }

    val sourceLanguage get() = Languages.find(sourceLangId)
    val targetLanguage get() = Languages.find(targetLangId)
    val textColor get() = palette[colorIndex.coerceIn(0, palette.lastIndex)]

    fun resetAppearance() {
        fontSize = 24f
        opacity = 0.85f
        colorIndex = 0
        showOriginal = true
        showPronunciation = false
        overlayPosition = OverlayPosition.AUTO
    }

    companion object {
        val palette = listOf(
            Color(0xFFFFD142), Color.White, Color(0xFF78E6FF), Color(0xFF8CF299),
            Color(0xFFFF9E4D), Color(0xFFFF738C), Color(0xFFCC99FF),
        )
    }

    // ---- ตัวช่วยเก็บค่า ----

    private fun stringPref(key: String, default: String) = object : ReadWriteProperty<Any?, String> {
        var state by mutableStateOf(prefs.getString(key, default) ?: default)
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            if (state == value) return
            state = value
            prefs.edit().putString(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun boolPref(key: String, default: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        var state by mutableStateOf(prefs.getBoolean(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            if (state == value) return
            state = value
            prefs.edit().putBoolean(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun intPref(key: String, default: Int) = object : ReadWriteProperty<Any?, Int> {
        var state by mutableStateOf(prefs.getInt(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            if (state == value) return
            state = value
            prefs.edit().putInt(key, value).apply()
            onChange?.invoke()
        }
    }

    private fun floatPref(key: String, default: Float) = object : ReadWriteProperty<Any?, Float> {
        var state by mutableStateOf(prefs.getFloat(key, default))
        override fun getValue(thisRef: Any?, property: KProperty<*>) = state
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
            if (state == value) return
            state = value
            prefs.edit().putFloat(key, value).apply()
            onChange?.invoke()
        }
    }
}
