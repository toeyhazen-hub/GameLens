package com.gamelens.app

import android.hardware.usb.UsbDevice
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import com.herohan.uvcapp.CameraException
import com.herohan.uvcapp.CameraHelper
import com.herohan.uvcapp.ICameraHelper
import com.serenegiant.usb.IFrameCallback
import com.serenegiant.usb.Size
import com.serenegiant.usb.UVCCamera
import java.nio.ByteBuffer

/**
 * รับภาพจาก Capture Card (UVC) ผ่าน USB-C ด้วยไลบรารี UVCAndroid
 * ทำงานได้บนแท็บเล็ต Android ทั่วไปโดยไม่ต้องรูทเครื่อง
 * ทุกฟังก์ชันเรียกบน main thread
 */
class UvcCapture(private val listener: Listener) {

    interface Listener {
        fun onCaptureStatus(text: String, live: Boolean)
        fun onFrameSize(width: Int, height: Int)
    }

    /** รับเฟรม NV21 (เรียกบน thread ของไลบรารี ต้องทำงานเร็ว และห้ามเก็บ buffer ไว้ใช้ภายหลัง) */
    @Volatile var frameSink: ((ByteBuffer, Int, Int) -> Unit)? = null

    @Volatile var lastFrameTime = 0L
        private set

    /** ครั้งแรกเลือก 1080p/60fps ถ้าจอดำให้สลับไปใช้ค่ามาตรฐานของการ์ด */
    var useBestSize = true

    var isOpen = false
        private set

    private val main = Handler(Looper.getMainLooper())
    private var helper: CameraHelper? = null
    private val surfaces = linkedSetOf<Surface>()
    @Volatile private var frameWidth = 0
    @Volatile private var frameHeight = 0
    private var deviceName = "Capture Card"

    private val frameCallback = IFrameCallback { frame ->
        lastFrameTime = SystemClock.elapsedRealtime()
        val w = frameWidth
        val h = frameHeight
        if (w > 0 && h > 0) frameSink?.invoke(frame, w, h)
    }

    private val stateCallback = object : ICameraHelper.StateCallback {
        override fun onAttach(device: UsbDevice) {
            // จะมีหน้าต่างขออนุญาตใช้ USB ครั้งแรก
            helper?.selectDevice(device)
        }

        override fun onDeviceOpen(device: UsbDevice, isFirstOpen: Boolean) {
            deviceName = device.productName ?: "Capture Card"
            helper?.openCamera()
        }

        override fun onCameraOpen(device: UsbDevice) {
            val h = helper ?: return
            isOpen = true
            val best = if (useBestSize) chooseBestSize(h.supportedSizeList) else null
            val size = best ?: h.previewSize
            if (best != null) h.setPreviewSize(best)
            if (size != null) {
                frameWidth = size.width
                frameHeight = size.height
                listener.onFrameSize(size.width, size.height)
            }
            h.startPreview()
            surfaces.forEach { h.addSurface(it, false) }
            h.setFrameCallback(frameCallback, UVCCamera.PIXEL_FORMAT_NV21)
            lastFrameTime = SystemClock.elapsedRealtime()
            listener.onCaptureStatus(deviceName, true)
        }

        override fun onCameraClose(device: UsbDevice) {
            isOpen = false
            surfaces.forEach { helper?.removeSurface(it) }
        }

        override fun onDeviceClose(device: UsbDevice) {
            isOpen = false
        }

        override fun onDetach(device: UsbDevice) {
            isOpen = false
            listener.onCaptureStatus("Capture Card ถูกถอดออก — เสียบกลับเพื่อใช้งานต่อ", false)
        }

        override fun onCancel(device: UsbDevice) {
            isOpen = false
            listener.onCaptureStatus("ไม่ได้รับอนุญาตให้ใช้ USB — กด เริ่มภาพใหม่ แล้วกด อนุญาต", false)
        }

        override fun onError(device: UsbDevice, e: CameraException) {
            isOpen = false
            listener.onCaptureStatus("เปิด Capture Card ไม่สำเร็จ กำลังลองใหม่…", false)
            main.postDelayed({ restart() }, 1500)
        }
    }

    fun start() {
        if (helper == null) {
            listener.onCaptureStatus("กำลังค้นหา Capture Card…", false)
            helper = CameraHelper().also { it.setStateCallback(stateCallback) }
        }
        // ถ้าเสียบไว้ก่อนเปิดแอป บางเครื่องไม่แจ้ง onAttach จึงเลือกอุปกรณ์เองอีกทาง
        main.postDelayed({
            val h = helper ?: return@postDelayed
            if (!isOpen) {
                val device = h.deviceList?.firstOrNull()
                if (device != null) h.selectDevice(device)
                else listener.onCaptureStatus("ไม่พบ Capture Card — เสียบสายเข้าพอร์ต USB-C แล้วรอสักครู่", false)
            }
        }, 1200)
    }

    fun stop() {
        main.removeCallbacksAndMessages(null)
        helper?.let { h ->
            surfaces.forEach { h.removeSurface(it) }
            h.release()
        }
        helper = null
        isOpen = false
    }

    /** ปิดแล้วเปิดใหม่ทั้งหมด */
    fun restart() {
        stop()
        listener.onCaptureStatus("กำลังเริ่มภาพใหม่…", false)
        main.postDelayed({ start() }, 800)
        lastFrameTime = SystemClock.elapsedRealtime() + 2000
    }

    fun addSurface(surface: Surface) {
        surfaces += surface
        if (isOpen) helper?.addSurface(surface, false)
    }

    fun removeSurface(surface: Surface) {
        surfaces -= surface
        helper?.removeSurface(surface)
    }

    /** เลือกขนาดใหญ่สุดไม่เกิน 1080p เน้น MJPEG (ส่งผ่าน USB ได้ลื่นกว่า) และ 60fps */
    private fun chooseBestSize(sizes: List<Size>?): Size? {
        val candidates = sizes.orEmpty().filter { it.width <= 1920 && it.height <= 1080 }
        val best = candidates.maxWithOrNull(
            compareBy<Size>(
                { it.width * it.height },
                { if (it.type == UVCCamera.UVC_VS_FRAME_MJPEG) 1 else 0 },
                { it.fpsList?.maxOrNull() ?: it.fps },
            )
        ) ?: return null
        val chosen = best.clone()
        val fpsList = best.fpsList.orEmpty()
        if (60 in fpsList) chosen.fps = 60 else fpsList.maxOrNull()?.let { chosen.fps = it }
        return chosen
    }
}
