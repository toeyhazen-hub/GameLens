package com.gamelens.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicBoolean

/** ศูนย์กลางของแอป: รับภาพ → OCR → รอข้อความนิ่ง → แปล → แสดงผล */
class AppViewModel(app: Application) : AndroidViewModel(app), UvcCapture.Listener {
    val settings = AppSettings(app)
    val capture = UvcCapture(this)
    private val audio = AudioPassthrough(app)
    private val ocr = OcrEngine()
    val mlKit = MlKitTranslate()
    private val stabilizer = TextStabilizer()
    private val cache = HashMap<String, String>()
    private var translationGeneration = 0

    // สถานะภาพ
    var status by mutableStateOf("กำลังเริ่มต้น…")
    var isLive by mutableStateOf(false)
    var contentWidth by mutableStateOf(1920)
    var contentHeight by mutableStateOf(1080)
    var testImage by mutableStateOf<Bitmap?>(null)
    var audioStatus by mutableStateOf("")
    var externalDisplayConnected by mutableStateOf(false)

    // การใช้งาน
    var isPaused by mutableStateOf(false)
    var isSelectingRegion by mutableStateOf(false)

    // ผลลัพธ์
    var originalText by mutableStateOf("")
    var pronunciation by mutableStateOf<String?>(null)
    var translatedText by mutableStateOf("")
    var isTranslating by mutableStateOf(false)
    val history = mutableStateListOf<HistoryEntry>()

    // สถานะ ML Kit
    var mlKitReady by mutableStateOf<Boolean?>(null)
    var mlKitDownloading by mutableStateOf(false)

    // OCR worker
    private val ocrBusy = AtomicBoolean(false)
    @Volatile private var lastOcrTime = 0L
    @Volatile private var forceNext = false
    @Volatile private var ocrRoi: NormRect? = null
    @Volatile private var ocrLanguage: GameLanguage = Languages.all[0]
    @Volatile private var ocrIntervalMs = 400L
    @Volatile private var ocrPaused = false

    private var started = false
    private var inBackground = false
    private var restartAttempts = 0
    private var audioJob: Job? = null
    private var lastLanguageKey = ""
    private var lastAudioEnabled = settings.audioEnabled

    init {
        settings.onChange = { settingsChanged() }
        capture.frameSink = { buffer, w, h -> onFrame(buffer, w, h) }
        stabilizer.requiredStableCount = settings.stableFrames
        audio.volume = settings.audioVolume
        lastLanguageKey = languageKey()
        pushOcrConfig()
        startWatchdog()
        refreshMlKitStatus()
    }

    // ---------- วงจรชีวิต ----------

    /** เรียกเมื่อแอปอยู่หน้าจอและได้สิทธิ์กล้องแล้ว */
    fun onForeground() {
        inBackground = false
        started = true
        if (testImage == null) {
            restartAttempts = 0
            capture.start()
        }
    }

    fun onBackground() {
        inBackground = true
        stopAudio()
        capture.stop()
        isLive = false
    }

    fun retryCapture() {
        restartAttempts = 0
        if (testImage == null) capture.restart()
    }

    override fun onCleared() {
        stopAudio()
        capture.stop()
        super.onCleared()
    }

    // ---------- UvcCapture.Listener ----------

    override fun onCaptureStatus(text: String, live: Boolean) {
        status = text
        isLive = live
        if (live) {
            restartAttempts = 0
            scheduleAudioStart()
        } else {
            stopAudio()
        }
    }

    override fun onFrameSize(width: Int, height: Int) {
        if (testImage == null) {
            contentWidth = width
            contentHeight = height
        }
    }

    /** ตรวจทุก 1 วินาที ถ้าภาพหยุดเกิน 3 วินาทีให้เริ่มใหม่อัตโนมัติ */
    private fun startWatchdog() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                if (!started || inBackground || testImage != null || !isLive) continue
                val silence = SystemClock.elapsedRealtime() - capture.lastFrameTime
                if (silence < 1500) {
                    if (settings.audioEnabled && !audio.isRunning && audioJob == null) scheduleAudioStart(500)
                    continue
                }
                if (silence > 3000) {
                    restartAttempts++
                    if (restartAttempts > 6) {
                        isLive = false
                        status = "ไม่ได้รับภาพจาก Capture Card — ลองถอดสายแล้วเสียบใหม่ หรือแตะ เริ่มภาพใหม่"
                        continue
                    }
                    capture.useBestSize = restartAttempts % 2 == 0
                    status = "ไม่ได้รับภาพ กำลังเริ่มใหม่อัตโนมัติ…"
                    capture.restart()
                }
            }
        }
    }

    // ---------- เสียง ----------

    private fun scheduleAudioStart(delayMs: Long = 1200) {
        audioJob?.cancel()
        audioJob = viewModelScope.launch {
            delay(delayMs)
            updateAudio()
            audioJob = null
        }
    }

    private fun stopAudio() {
        audioJob?.cancel()
        audioJob = null
        audio.stop()
    }

    private suspend fun updateAudio() {
        if (!settings.audioEnabled || !isLive) {
            audio.stop()
            audioStatus = if (settings.audioEnabled) "" else "ปิดเสียงเกมอยู่"
            return
        }
        val error = withContext(Dispatchers.IO) { audio.start() }
        audioStatus = error ?: "กำลังเล่นเสียงเกม"
    }

    // ---------- การตั้งค่า ----------

    private fun languageKey() = "${settings.sourceLangId}>${settings.targetLangId}>${settings.engine.name}"

    private fun settingsChanged() {
        pushOcrConfig()
        stabilizer.requiredStableCount = settings.stableFrames
        audio.volume = settings.audioVolume
        val key = languageKey()
        if (key != lastLanguageKey) {
            lastLanguageKey = key
            stabilizer.reset()
            clearSubtitles()
            refreshMlKitStatus()
        }
        if (settings.audioEnabled != lastAudioEnabled) {
            lastAudioEnabled = settings.audioEnabled
            viewModelScope.launch { updateAudio() }
        }
    }

    private fun pushOcrConfig() {
        ocrRoi = if (testImage == null) settings.roi else null
        ocrLanguage = settings.sourceLanguage
        ocrIntervalMs = (settings.ocrInterval * 1000).toLong()
        ocrPaused = isPaused || isSelectingRegion
    }

    fun togglePause() {
        isPaused = !isPaused
        pushOcrConfig()
    }

    fun setSelecting(value: Boolean) {
        isSelectingRegion = value
        pushOcrConfig()
    }

    fun refreshMlKitStatus() {
        viewModelScope.launch {
            mlKitReady = if (settings.sourceLangId == settings.targetLangId) true
            else mlKit.isReady(settings.sourceLanguage, settings.targetLanguage)
        }
    }

    fun downloadMlKit() {
        if (mlKitDownloading) return
        mlKitDownloading = true
        viewModelScope.launch {
            try {
                mlKit.download(settings.sourceLanguage, settings.targetLanguage)
            } catch (e: Exception) {
                status = "ดาวน์โหลดภาษาไม่สำเร็จ: ${e.message}"
            }
            mlKitDownloading = false
            refreshMlKitStatus()
        }
    }

    // ---------- กรอบ OCR ----------

    fun setRegion(roi: NormRect) {
        settings.roi = roi
        setSelecting(false)
        stabilizer.reset()
        clearSubtitles()
        if (testImage != null) runImageOcr()
    }

    fun clearRegion() {
        settings.roi = null
        stabilizer.reset()
        clearSubtitles()
    }

    fun translateNow() {
        if (settings.roi == null) {
            status = "ตีกรอบบริเวณข้อความก่อน"
            setSelecting(true)
            return
        }
        if (testImage != null) runImageOcr() else forceNext = true
    }

    // ---------- โหมดทดสอบด้วยภาพ ----------

    fun loadTestImage(uri: Uri) {
        viewModelScope.launch {
            val bitmap = try {
                withContext(Dispatchers.IO) {
                    val source = ImageDecoder.createSource(getApplication<Application>().contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                }
            } catch (e: Exception) {
                status = "เปิดรูปไม่ได้: ${e.message}"
                return@launch
            }
            stopAudio()
            capture.stop()
            isLive = false
            testImage = bitmap
            contentWidth = bitmap.width
            contentHeight = bitmap.height
            status = "โหมดทดสอบด้วยภาพ"
            pushOcrConfig()
            stabilizer.reset()
            clearSubtitles()
            if (settings.roi != null) runImageOcr()
        }
    }

    fun exitTestImage() {
        testImage = null
        clearSubtitles()
        stabilizer.reset()
        pushOcrConfig()
        restartAttempts = 0
        capture.start()
    }

    private fun runImageOcr() {
        val bitmap = testImage ?: return
        val roi = settings.roi ?: return
        val language = settings.sourceLanguage
        status = "กำลังอ่านข้อความ…"
        viewModelScope.launch {
            val text = try {
                withContext(Dispatchers.Default) { ocr.recognizeBitmap(bitmap, roi, language) }
            } catch (e: Exception) {
                ""
            }
            status = "โหมดทดสอบด้วยภาพ"
            handleText(text, forced = true)
        }
    }

    // ---------- OCR จากภาพสด ----------

    /** เรียกบน thread ของไลบรารีกล้อง: คัดลอกเฟรมเฉพาะตอนที่ต้อง OCR แล้วส่งไปทำงานอีก thread */
    private fun onFrame(buffer: java.nio.ByteBuffer, width: Int, height: Int) {
        val roi = ocrRoi ?: return
        val now = SystemClock.elapsedRealtime()
        val force = forceNext
        if (!force && (ocrPaused || now - lastOcrTime < ocrIntervalMs)) return
        if (!ocrBusy.compareAndSet(false, true)) return
        forceNext = false
        lastOcrTime = now
        val expected = width * height * 3 / 2
        if (buffer.remaining() < expected) {
            ocrBusy.set(false)
            return
        }
        val bytes = ByteArray(expected)
        buffer.get(bytes, 0, expected)
        val language = ocrLanguage
        viewModelScope.launch(Dispatchers.Default) {
            val text = try {
                ocr.recognizeNv21(bytes, width, height, roi, language)
            } catch (e: Exception) {
                ""
            } finally {
                ocrBusy.set(false)
            }
            withContext(Dispatchers.Main) { handleText(text, force) }
        }
    }

    private fun handleText(text: String, forced: Boolean) {
        if (forced) {
            if (text.isEmpty()) {
                status = "ไม่พบข้อความในกรอบ"
                return
            }
            stabilizer.markEmitted(text)
            translate(text)
            return
        }
        if (isPaused) return
        when (val event = stabilizer.feed(text)) {
            is TextStabilizer.Event.None -> Unit
            is TextStabilizer.Event.Cleared -> if (settings.hideWhenNoText) clearSubtitles()
            is TextStabilizer.Event.NewText -> translate(event.text)
        }
    }

    // ---------- แปล ----------

    private fun translate(text: String) {
        val source = settings.sourceLanguage
        val target = settings.targetLanguage
        val engine = settings.engine
        originalText = text
        pronunciation = if (settings.showPronunciation) Pronunciation.romanize(text, source) else null

        if (source.id == target.id) {
            show(text, text)
            return
        }
        val cacheKey = "${engine.name}|${source.id}|${target.id}|$text"
        cache[cacheKey]?.let {
            show(it, text)
            return
        }

        translationGeneration++
        val generation = translationGeneration
        translatedText = ""
        isTranslating = true
        val context = history.takeLast(6)

        viewModelScope.launch {
            try {
                val result = when (engine) {
                    TranslationEngine.MLKIT -> translateWithMlKit(text, source, target)
                    TranslationEngine.GOOGLE -> GoogleFreeTranslate.translate(text, source, target)
                    TranslationEngine.MYMEMORY ->
                        MyMemoryTranslate.translate(text, source, target, settings.myMemoryEmail)
                    TranslationEngine.CLAUDE -> ClaudeTranslate.translate(
                        text, source, target, settings.claudeApiKey, settings.claudeModel, context
                    )
                }
                if (cache.size > 500) cache.clear()
                cache[cacheKey] = result
                if (generation == translationGeneration) show(result, text)
            } catch (e: Exception) {
                if (generation == translationGeneration) {
                    isTranslating = false
                    translatedText = "⚠️ ${e.message ?: "แปลไม่สำเร็จ"}"
                }
            }
        }
    }

    /** ML Kit: ถ้ายังไม่ได้ดาวน์โหลดภาษา หรือช้าเกินไป ให้ใช้ Google แทน (ถ้าเปิดไว้) */
    private suspend fun translateWithMlKit(text: String, source: GameLanguage, target: GameLanguage): String {
        val fallback = settings.fallbackToGoogle
        if (fallback && mlKitReady == false) {
            if (!mlKitDownloading) downloadMlKit()
            return GoogleFreeTranslate.translate(text, source, target)
        }
        return try {
            withTimeout(8000) { mlKit.translate(text, source, target) }
        } catch (e: Exception) {
            if (!fallback) throw e
            GoogleFreeTranslate.translate(text, source, target)
        }
    }

    private fun show(translation: String, original: String) {
        isTranslating = false
        translatedText = translation
        if (history.lastOrNull()?.original != original) {
            history += HistoryEntry(original, translation)
            while (history.size > 300) history.removeAt(0)
        }
    }

    private fun clearSubtitles() {
        translationGeneration++
        originalText = ""
        pronunciation = null
        translatedText = ""
        isTranslating = false
    }
}
